OPENQASM 2.0;
include "qelib1.inc";
gate gate_EfficientSU2(param0,param1,param2,param3,param4,param5,param6,param7,param8,param9,param10,param11,param12,param13,param14,param15,param16,param17,param18,param19,param20,param21,param22,param23) q0,q1,q2,q3,q4,q5 { ry(pi) q0; ry(pi) q1; ry(0) q2; ry(0) q3; ry(0) q4; ry(pi/4) q5; rz(pi/4) q0; rz(-pi/2) q1; rz(-pi/2) q2; rz(0) q3; rz(0) q4; rz(0) q5; cx q0,q1; cx q1,q2; cx q2,q3; cx q3,q4; cx q4,q5; ry(pi) q0; ry(-pi/4) q1; ry(pi/4) q2; ry(pi/4) q3; ry(pi/4) q4; ry(pi) q5; rz(0) q0; rz(pi) q1; rz(-pi/2) q2; rz(0) q3; rz(-pi/2) q4; rz(pi/2) q5; }
qreg q[6];
gate_EfficientSU2(pi,pi,0,0,0,pi/4,pi/4,-pi/2,-pi/2,0,0,0,pi,-pi/4,pi/4,pi/4,pi/4,pi,0,pi,-pi/2,0,-pi/2,pi/2) q[0],q[1],q[2],q[3],q[4],q[5];